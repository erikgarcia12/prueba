<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="https://getbootstrap.com/docs/3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/style.css')); ?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/datatables/dataTables.bootstrap.css')); ?>">
<script src="http://code.jquery.com/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('public/js/jquery-2.1.1.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/jquery-validate.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/js/jquery.dataTables.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('public/js/dataTables.bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/jquery.mask.js')); ?>"></script>