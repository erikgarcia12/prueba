<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\User;

class PruebaController extends Controller
{
    public function index(){
    	return view('front.index');
    }

    public function crearUsuario(){
    	return view('front.crear-usuario');
    }

    public function saveUser(Request $request){
    	$name 			= $request->input('name');
    	$email 			= $request->input('email');
    	$job_position 	= $request->input('job_position');
    	$birthdate 		= $request->input('birthdate');
    	$home 			= $request->input('home');

    	$edit_user 		= new User;
    		$edit_user->name 			= $name;
    		$edit_user->email 			= $email;
    		$edit_user->job_position 	= $job_position;
    		$edit_user->birthdate 		= $birthdate;
    		$edit_user->home 			= $home;
    	$edit_user->save();

    	return redirect('/');
    }

    public function editarUsuario($id_user){
    	$user 	= User::find($id_user);
    	return view('front.editar-usuario', array('user' => $user, 'id_user' => $id_user));
    }

    public function saveEditUser(Request $request){
    	$name 			= $request->input('name');
    	$email 			= $request->input('email');
    	$job_position 	= $request->input('job_position');
		$birthdate 		= $request->input('birthdate');
    	$home 			= $request->input('home');
    	$id_user 		= $request->input('id_user');

    	$edit_user 		= User::find($id_user);
    		$edit_user->name 			= $name;
    		$edit_user->email 			= $email;
    		$edit_user->job_position 	= $job_position;
    		$edit_user->birthdate 		= $birthdate;
    		$edit_user->home 			= $home;
    	$edit_user->save();

    	return redirect('/');
    }

    public function listUsers(){
    	$users 	= User::all();
    	$array 	= array();
    	foreach ($users as $item) {
    		array_push($array, array(
    			"id" 			=> $item->id,
				"name"			=> $item->name,
				"job_position" 	=> $item->job_position,
				"birthdate" 	=> $item->birthdate,
				"home" 			=> $item->home
    		));
    	}

    	$user = array("aaData" => $array);
 		return response()->json($user);
    }
}
