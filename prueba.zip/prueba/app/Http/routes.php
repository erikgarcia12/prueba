<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', 'PruebaController@index');
Route::get('/crear-usuario', 'PruebaController@crearUsuario');
Route::post('/save-user', 'PruebaController@saveUser');
Route::get('/editar-usuario/{id_user}', 'PruebaController@editarUsuario');
Route::post('/save-edit-user', 'PruebaController@saveEditUser');
Route::get('list-users', 'PruebaController@listUsers');
