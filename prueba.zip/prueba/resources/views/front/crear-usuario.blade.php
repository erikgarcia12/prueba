@extends('layouts.app')
@section('content')
<article class="article-template">
	<section>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-sm-offset-3 col-md-offset-3 col-lg-offset-3">
					<div class="form-class">
						<div class="title">
							<h3>
								Registrar nuevo usuario
							</h3>
						</div>
						<div class="content-form">
							<form action="{{URL::to('save-user')}}" method="POST" id="form">
								{!! csrf_field() !!}
								<div class="form-group">
									<span>Nombre*</span>
									<input type="text" name="name" class="form-control input-lg">
								</div>
								<div class="form-group">
									<span>Email*</span>
									<input type="text" name="email" class="form-control input-lg">
								</div>
								<div class="form-group">
									<span>Puesto*</span>
									<input type="text" name="job_position" class="form-control input-lg">
								</div>
								<div class="form-group">
									<span>Fecha de nacimiento*</span>
									<input name="birthdate" id="birthdate" class="form-control input-lg" placeholder="dd-mm-yyyy" type="text">
								</div>
								<div class="form-group">
									<span>Domicilio*</span>
									<input type="text" name="home" class="form-control input-lg" placeholder="Calle, # y Colonia">
								</div>
								<div class="form-group">
									<button type="submit" class="btn btn-success btn-lg">
										<i class="fa fa-external-link" aria-hidden="true"></i> Guardar
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</article>
<script>
	$(document).on('click', '#birthdate', function () {
		var me = $("#birthdate");
		me.datepicker({
			showOn: 'focus',
			altFormat: "dd/mm/yy",
			dateFormat: "dd/mm/yy",
			minDate: '12/12/1900',
			maxDate: '12/12/2020'
		}).focus();
	}).on('focus', '#birthdate', function () {
		var me = $("#birthdate");
		me.mask('99/99/9999');
	});
</script>
<script>
	$(document).ready(function(){
		$('#form').validate({
			rules:{
				'name': 		{required: true},
				'email': 		{required: true, email: true},
				'job_position': {required: true},
				'birthdate': 	{required: true},
				'home': 		{required: true}
			},
			messages:{
				'name': 		{required: "Ingresa un nombre"},
				'email': 		{required: "Ingresa un email", email: "Ingresa un email valido"},
				'job_position': {required: "Ingresa un puesto"},
				'birthdate': 	{required: "Ingresa una fecha de nacimiento"},
				'home': 		{required: "Ingresa un domiclio"}
			},
			submitHandler: function(form){
				form.submit();
			}
		});
	});
</script>
@stop