@extends('layouts.app')
@section('content')
<article class="article-template">
	<section>
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
					<div class="new_user">
						<a href="{{URL::to('crear-usuario')}}">
							<div class="card-new-user">
								<i class="fa fa-plus-circle fa-4x" aria-hidden="true"></i>
								<p>
									Crear nuevo usuario
								</p>
							</div>
						</a>
					</div>
				</div>
			</div>
			<div class="row" id="list-users">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<div class="users-list">
						<div class="box-body">
							<div>
								<h3>Lista de usuarios:</h3>
							</div>
							<table class="table table-bordered table-striped" id="users">
								<thead>
									<tr>
										<th width="10%">ID</th>
										<th width="25%">Nombre</th>
										<th width="25%">Puesto</th>
										<th width="20%">Fecha de nacimiento</th>
										<th width="10%">Domicilio</th>
										<th width="10%">Editar</th>
										<th>Mapa</th>
									</tr>
								</thead>
								<tbody>

								</tbody>
								<tfoot>
									<tr>
										<th width="10%">ID</th>
										<th width="25%">Nombre</th>
										<th width="25%">Puesto</th>
										<th width="20%">Fecha de nacimiento</th>
										<th width="10%">Domicilio</th>
										<th width="10%">Editar</th>
									</tr>
								</tfoot>
							</table>
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</section>
<script>
	$(document).ready(function(){
		var table =  $("#users").DataTable({
			"processing"  : true,
			"sAjaxSource" : "{{URL::to('list-users')}}",
			"aoColumns"   : [
				{"mData"    : "id", "className" : "id"},
				{"mData"    : "name"},
				{"mData"    : "job_position"},
				{"mData"    : "birthdate"},
				{"mData"    : "home", "className": "map_home"},
				{"defaultContent": "<div align='center'><button class='btn btn-primary' id='edit'><i class='fa fa-pencil-square-o' aria-hidden='true'></i></button></div>"},
				{"defaultContent": "<div align='center'><button class='btn btn-primary' id='map'><i class='fa fa-map-marker' aria-hidden='true'></i></button></div>"},
			]
		});

		$('#users tbody').on('click', '#edit', function(){
			var id 			= $(this).parents('tr').find('.id').text();
			var path 		= '{{URL::to("editar-usuario")}}' + '/' + id;
			location.href 	= path;
		});

		$('#users tbody').on('click', '#map', function(){
			var map 			= $(this).parents('tr').find('.map_home').text();
			mapa.getCoords(map);
		});
	});
</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCp8xF_B3IDY9qQQmjS-11rESPBsNCPndo"></script>
<script>
	mapa = {
		map : false,
		marker : false,
		initMap : function() {
			// Creamos un objeto mapa y especificamos el elemento DOM donde se va a mostrar.
			mapa.map = new google.maps.Map(document.getElementById('mapa'), {
				center: {lat: 43.2686751, lng: -2.9340005},
				scrollwheel: false,
				zoom: 14,
				zoomControl: true,
				rotateControl : false,
				mapTypeControl: true,
				streetViewControl: false,
			});
			// Creamos el marcador
			mapa.marker = new google.maps.Marker({
				position: {lat: 43.2686751, lng: -2.9340005},
				draggable: true
			});
			// Le asignamos el mapa a los marcadores.
			mapa.marker.setMap(mapa.map);
		},

		// función que se ejecuta al pulsar el botón buscar dirección
		getCoords : function(map){
			// Creamos el objeto geodecoder
			var geocoder = new google.maps.Geocoder();
			address = map;
			if(address!=''){
				// Llamamos a la función geodecode pasandole la dirección que hemos introducido en la caja de texto.
				geocoder.geocode({ 'address': address}, function(results, status){
					if (status == 'OK')
					{
						window.open("https://maps.google.com/?q="+results[0].geometry.location.lat()+"," + results[0].geometry.location.lng());
					}
				});
			}
		}
	}
</script>
</article>
@stop